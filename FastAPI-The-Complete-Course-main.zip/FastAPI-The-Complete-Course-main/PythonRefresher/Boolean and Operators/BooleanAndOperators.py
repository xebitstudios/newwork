"""
Boolean and Operators
"""

# Comparison Operators
print(1 == 2)
print(1 != 2)
print(1 > 2)
print(1 < 2)
print(1 >= 1)
print(1 <= 2)


# Logical Operators
print(1 > 3 and 5 < 7)
print(1 > 3 or 5 < 7)
print(not(1 == 1))


