class Animal:

    def talk(self): 
        print('Does not make a sound')